package com.example.product.exception;

public class ResourceNotFoundException {

}
