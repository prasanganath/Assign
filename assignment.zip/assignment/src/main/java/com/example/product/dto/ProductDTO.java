package com.example.product.dto;

public class ProductDTO {
    private String name;
    private String description;
    private double price;
    private String category;

    // Getters and Setters
}
