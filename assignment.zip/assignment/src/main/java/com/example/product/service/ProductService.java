import com.example.product.entity.Product;
import com.example.product.entity.ProductCategory;
import com.example.product.exception.ResourceNotFoundException;
import com.example.product.repository.ProductCategoryRepository;
import com.example.product.repository.ProductRepository;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private ProductCategoryRepository categoryRepository;

    public Product createProduct(String name, String description, double price, String categoryName) {
        ProductCategory category = categoryRepository.findByName(categoryName);
        Product product = new Product(name, description, price, category);
        return productRepository.save(product);
    }

    public Product updateProduct(Long id, String name, String description, double price) {
        Product product = productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        return productRepository.save(product);
    }

    public void deleteProduct(Long id) {
        Product product = productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        product.setStatus("D");
        productRepository.save(product);
    }

    public List<Product> getProductsByCategory(String categoryName) {
        return productRepository.findByCategoryName(categoryName);
    }

    public List<Product> getPremiumProducts() {
        return productRepository.findByPriceGreaterThanEqual(500.0);
    }
}
