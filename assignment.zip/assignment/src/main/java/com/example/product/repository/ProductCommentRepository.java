package com.example.product.repository;

public class ProductCommentRepository {

}
